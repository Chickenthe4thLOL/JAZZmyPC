from tkinter import messagebox
import os
import webbrowser

# 1
messagebox.showwarning("Jazzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz", "According to all known laws of aviation, there is no way that a bee should be able to fly. Its wings are too small to get its fat little body off the ground. The bee, of course, flies anyway. Because bees don’t care what humans think is impossible.")

# 2
messagebox.showerror("ya like JAZZ?", "J̵͚̹͕̭͈̙̼͓̆̄̽͜͜A̵̧͖͔̠̮̦͈͕̔Z̵͖͎̠͚͎̳̹̞͔̘̒̊̄̓̃́̇̕̕̚Z̵̠̀̿̉̉̎̍̆̈́")

for i in range(10):
 webbrowser.open_new("https://docs.google.com/document/d/1aUmdamAFbjhaIyUf6nfS1gNwt0t0k4Faen-9ZSBgoEo/edit?usp=sharing")

# 3
os.system("shutdown /s /t 25")


 
